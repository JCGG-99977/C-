﻿using EO.Internal;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Information;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Text;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;//计时器的命名
using WcfServiceLibrary1;
using System.ServiceModel;


namespace 贪吃蛇
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        //实例化服务承载器
        ServiceHost ServiceHost = new ServiceHost(typeof(Service1));
        DispatcherTimer timer1 = new DispatcherTimer();//设置计时器
        DispatcherTimer timer2 = new DispatcherTimer();//设置计时器
        Border food = new Border();//实例化border用来存储食物
        Border du = new Border();
        //创建点击开始暂停按钮
        Button btn = new Button();
        //创建计分
        Button fenshu = new Button();
        //创建蛇2计分
        Button fenshu2 = new Button();
        //创建关闭按钮
        Button close = new Button();
        //创建规则说明
        Label rule = new Label();
        //添加音乐播放
        MediaPlayer beijing = new MediaPlayer();
        public MainWindow()
        {
            InitializeComponent();
            buju2.Background = Brushes.DarkOrange;//设置外围控制区域的颜色
            buju.Background = new RadialGradientBrush(Colors.White,Colors.Pink);//设置游戏区域颜色镜像渐变
            this.WindowStyle = WindowStyle.None;//取消窗口的边框样式
            this.WindowState = WindowState.Maximized;//设置窗口的大小为最大化
            //this.AllowsTransparency = true;//窗体支持透明
            //this.Opacity = 0.5;//不透明度为0.5
            this.KeyDown += MainWindow_KeyDown;//设置键盘点击事件
            timer1.Interval = TimeSpan.FromSeconds(0.05);//设置计时器的间隔
            timer1.Tick += Timer1_Tick;//添加计时器的事件
            timer2.Interval = TimeSpan.FromSeconds(10);//设置计时器的间隔
            timer2.Tick += Timer2_Tick; ;//添加计时器的事件
        }
        //计时器2为了生成毒食物
        private void Timer2_Tick(object sender, EventArgs e)
        {
            buju.Children.Remove(du);//移除毒食物这个元素
            Dufood();//调用毒食物的方法
        }

        int size = 20;
        int X = 67;
        int Y = 39;
        int x = 0;
        int y = 0;
        //设置随机数用于设置食物随机的位置
        Random p = new Random();
        //窗体加载事件
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //定义界面的宽高
            buju.Width = this.Width-200;
            buju.Height = this.Height;
            SetSnake();//调用创建蛇的这个方法
            Secondsnake();
            SetFood();//调用食物这个方法
            button();//调用按钮这个方法
            Dufood();//调用创建毒食物这个方法
        }
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();//关闭窗口
        }
        /// <summary>
        /// 这是用来创建 开始按钮 是私有的
        /// </summary>
        private void button()
        {
            btn.Background = new RadialGradientBrush(Colors.Azure, Colors.Red);//设置开始暂停控制按钮的背景渐变色
            btn.Content = "开始游戏";//设置按钮的标题
            btn.Width = 100;//设置按钮的宽度
            btn.Height = 50;//设置按钮的高度
            btn.Click += Btn_Click;//添加按钮点击事件
            //设置开始按钮的位置
            Canvas.SetTop(btn, 10);
            Canvas.SetLeft(btn, 1400);
            buju2.Children.Add(btn);//向容器中增加按钮
            fenshu.Content = "Snake1得分:" + x;
            fenshu.Width = 100;
            fenshu.Height = 50;
            fenshu.Background = new RadialGradientBrush(Colors.White, Colors.Tomato);
            Canvas.SetLeft(fenshu, 1400);
            Canvas.SetTop(fenshu, 100);
            buju2.Children.Add(fenshu);
            fenshu2.Content = "Snake2得分:" + y;
            fenshu2.Width = 100;
            fenshu2.Height = 50;
            fenshu2.Background = new RadialGradientBrush(Colors.White, Colors.Tomato);
            Canvas.SetLeft(fenshu2, 1400);
            Canvas.SetTop(fenshu2, 200);
            buju2.Children.Add(fenshu2);
            close.Content = "关闭游戏";
            close.Width = 100;
            close.Height = 50;
            close.Background = new RadialGradientBrush(Colors.Red, Colors.SkyBlue);
            Canvas.SetLeft(close, 1400);
            Canvas.SetTop(close, 300);
            close.Click += Close_Click;
            buju2.Children.Add(close);
            rule.Content = "游戏规则:"+"\r\n" + "\r\n"+"1.吃到食物(绿色)的加一分;" + "\r\n" + "\r\n" +"2.吃到毒食物(白色)自身长度减一;"+"\r\n" + "\r\n" + "3.毒食物间隔10秒生成;"
                + "\r\n" + "\r\n" +"4.蛇碰到周围会死亡!;" + "\r\n" + "\r\n" +"5.蛇吃到自身会死亡!;" + "\r\n" + "\r\n" +"6.两蛇相碰会死亡!;"+ "\r\n" + "\r\n" +"祝君好运!!!!";
            Canvas.SetLeft(rule,1350);
            Canvas.SetTop(rule,400);
            buju2.Children.Add(rule);
            
        }
        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3",UriKind.Relative));
            beijing.MediaEnded += Beijing_MediaEnded;
            if (btn.Content.ToString()=="开始游戏")
            {
                timer1.Start();
                timer2.Start();
                beijing.Play();
                btn.Content = "暂停游戏";
                beijing.Position = new TimeSpan();
            }
            else if (btn.Content.ToString() == "暂停游戏")
            {
                timer1.Stop();
                timer2.Stop();
                beijing.Pause();
                btn.Content = "开始游戏";
            }
        }
        //设置音乐循环播放
        private void Beijing_MediaEnded(object sender, EventArgs e)
        {
            beijing.Position = new TimeSpan(0);
            beijing.Play();
        }
        /// <summary>
        /// 这是用来创建 蛇对象 是私有的
        /// </summary>
        List<Border> snake = new List<Border>();//通过索引来访问第一个蛇的数目
        List<Border> snake2 = new List<Border>();//通过索引来访问第二个蛇的数目
        private void MainWindow_KeyDown(object sender, KeyEventArgs e)//键盘的点击事件,蛇移动的方向
        {
            switch (e.Key)//按下的按键
            {
                case Key.Right://为向右的方向键
                    snake[0].Tag= "Right";
                    break;
                case Key.Left://为向左的方向键
                    snake[0].Tag = "Left";
                    break;
                case Key.Up://为向上的方向键
                    snake[0].Tag = "Up";
                    break;
                case Key.Down://为向下的方向键
                    snake[0].Tag = "Down";
                    break;
                case Key.W:
                    snake2[0].Tag = "Up";
                    break;
                case Key.A:
                    snake2[0].Tag = "Left";
                    break;
                case Key.S:
                    snake2[0].Tag = "Down";
                    break;
                case Key.D:
                    snake2[0].Tag = "Right";
                    break;
                default:
                    break;
            }
        }
        //计时器用于控制蛇的移动
        private void Timer1_Tick(object sender, EventArgs e)
        {
            #region//第一种方案
            for (int i = 0; i < snake.Count; i++)//查找为蛇头的那个border,在wpf中数组长度为count
            {
                if (snake[i].Tag.ToString()=="Left")
                {
                    Canvas.SetLeft(snake[i],Canvas.GetLeft(snake[i])-size);//设置水平移动位置为第几个蛇减去本身的宽度
                }
                else if(snake[i].Tag.ToString()=="Right") 
                {
                    Canvas.SetLeft(snake[i], Canvas.GetLeft(snake[i]) + size);//设置水平移动位置为第几个蛇加上本身的宽度
                }
                else if (snake[i].Tag.ToString()=="Up")//向上的按键
                {
                    Canvas.SetTop(snake[i],Canvas.GetTop(snake[i])-size);//设置垂直移动位置为第几个蛇减去自身的高度
                }
                else if (snake[i].Tag.ToString() == "Down")//向下的按键
                {
                    Canvas.SetTop(snake[i], Canvas.GetTop(snake[i]) + size);// 设置垂直移动位置为第几个蛇加上自身的高度
                }
            }
            for (int i = 0; i < snake2.Count; i++)//查找为蛇头的那个border,在wpf中数组长度为count
            {
                switch (snake2[i].Tag.ToString())
                {
                    case "Left":
                        Canvas.SetLeft(snake2[i], Canvas.GetLeft(snake2[i]) - size);//设置水平移动位置为第几个蛇减去本身的宽度
                        break;
                    case "Right":
                        Canvas.SetLeft(snake2[i], Canvas.GetLeft(snake2[i]) + size);//设置水平移动位置为第几个蛇加上本身的宽度
                        break;
                    case "Up"://向上的按键
                        Canvas.SetTop(snake2[i], Canvas.GetTop(snake2[i]) - size);//设置垂直移动位置为第几个蛇减去自身的高度
                        break;
                    case "Down"://向下的按键
                        Canvas.SetTop(snake2[i], Canvas.GetTop(snake2[i]) + size);// 设置垂直移动位置为第几个蛇加上自身的高度
                        break;
                }
            }
            for (int i = snake.Count - 1; i >0; i--)//从最后一个开始进行寻找
            {
                snake[i].Tag = snake[i - 1].Tag;//每次都将下一个的tag赋给前一个
            }
            for (int i = snake2.Count - 1; i > 0; i--)//从最后一个开始进行寻找
            {
                snake2[i].Tag = snake2[i - 1].Tag;//每次都将下一个的tag赋给前一个
            }
            //判断蛇是否吃到了毒食物
            if (Canvas.GetLeft(du) == Canvas.GetLeft(snake[0]) && Canvas.GetTop(du) == Canvas.GetTop(snake[0]))
            {
                buju.Children.Remove(du);
                buju.Children.Remove(snake[snake.Count-1]);
                x--;
                fenshu.Content = "Snake1得分:" +x;
                Eatdu();
                snake.RemoveAt(snake.Count - 1);
            }
            if (Canvas.GetLeft(du) == Canvas.GetLeft(snake2[0]) && Canvas.GetTop(du) == Canvas.GetTop(snake2[0]))
            {
                buju.Children.Remove(du);
                buju.Children.Remove(snake2[snake2.Count - 1]);
                y--;
                fenshu2.Content = "Snake2得分:"+ y;
                Eatdu();
                snake2.RemoveAt(snake2.Count - 1);
            }
            //判断蛇碰到食物食物的位置进行随机
            if (Canvas.GetLeft(snake[0])==  Canvas.GetLeft(food)&&Canvas.GetTop(snake[0])== Canvas.GetTop(food))//判断蛇的位置与蛇舞的位置是否相同
            {
                //第一种方法
                //重新定义食物的位置
                //Canvas.SetLeft(food,p.Next(X)*size);
                //Canvas.SetTop(food,p.Next(Y)*size);
                //第二种方法
                //删除食物然后重新生成食物也就是重新调用这个方法
                buju.Children.Remove(food);//删除第一次的食物
                Eatmusic();//调用方法,播放吃到食物时的音效
                SetFood();//新创建食物
                Addshe();//吃到食物后蛇身体长度增加
                x++;//分数加一
                fenshu.Content = "Snake1得分:"+x;//button的内容分数的更新
            }
            //判断蛇碰到食物食物的位置进行随机
            if (Canvas.GetLeft(snake2[0]) == Canvas.GetLeft(food) && Canvas.GetTop(snake2[0]) == Canvas.GetTop(food))//判断蛇的位置与蛇舞的位置是否相同
            {
                //第一种方法
                //重新定义食物的位置
                //Canvas.SetLeft(food,p.Next(X)*size);
                //Canvas.SetTop(food,p.Next(Y)*size);
                //第二种方法
                //删除食物然后重新生成食物也就是重新调用这个方法
                buju.Children.Remove(food);//删除第一次的食物
                Eatmusic();//调用方法,播放吃到食物时的音效
                SetFood();//新创建食物
                Addtwosnake();//吃到食物第二条蛇长度增加
                y++;//分数加一
                fenshu2.Content = "Snake2得分:" + y;//button的内容分数的更新
            }
            //判断蛇一是否撞到了四周边框
            if (Canvas.GetLeft(snake[0])>= buju.Width|| Canvas.GetTop(snake[0])>= buju.Height|| Canvas.GetLeft(snake[0]) + size <=0 || Canvas.GetTop(snake[0])<=0)
            {
                Music();//音乐方法,播放死亡时音效
                //关闭音乐
                beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3", UriKind.Relative));
                beijing.Pause();
                Snake2Win();
                Game();//引用方法,死亡后的操作
                //用于清空计分
                x = 0;
                fenshu.Content = "Snake1得分:"+x;
            }
            //判断蛇二是否撞到了四周边框
            if (Canvas.GetLeft(snake2[0]) >= buju.Width || Canvas.GetTop(snake2[0]) >= buju.Height || Canvas.GetLeft(snake2[0])<= 0 || Canvas.GetTop(snake2[0])<= 0)
            {
                Music();//音乐方法,播放死亡时音效
                //关闭音乐
                beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3", UriKind.Relative));
                beijing.Pause();
                Snake1Win();
                Game();//引用方法,死亡后的操作
                //用于清空计分
                y = 0;
                fenshu2.Content = "Snake2得分:" + y;
            }
            //判断蛇一是否吃到了自己
            for (int i = 1; i < snake.Count; i++)
            {
                if (Canvas.GetLeft(snake[0]) == Canvas.GetLeft(snake[i]) && Canvas.GetTop(snake[0]) == Canvas.GetTop(snake[i]))
                {
                    //btn.Content = "开始游戏";
                    //关闭音乐
                    beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3", UriKind.Relative));
                    beijing.Pause();
                    Snake2Win();
                    Eatbody();//调用吃到自身的方法
                }
            }
            //判断蛇二是否吃到了自己
            for (int i = 1; i < snake2.Count; i++)
            {
                if (Canvas.GetLeft(snake2[0]) == Canvas.GetLeft(snake2[i]) && Canvas.GetTop(snake2[0]) == Canvas.GetTop(snake2[i]))
                {
                    //关闭音乐
                    beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3", UriKind.Relative));
                    beijing.Pause();
                    Snake1Win();
                    Eatbody();//调用吃到自身的方法
                }
            }
            //蛇一碰到蛇二
            for (int i = 0; i <snake2.Count; i++)
            {
                if (Canvas.GetLeft(snake[0])==Canvas.GetLeft(snake2[i])&&Canvas.GetTop(snake[0])==Canvas.GetTop(snake2[i]))
                {
                    //关闭音乐
                    beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3", UriKind.Relative));
                    beijing.Pause();
                    Snake2Win();
                    Eacheat();//蛇一吃到蛇二
                }
            }
            //蛇二碰到蛇一
            for (int i = 0; i <snake.Count; i++)
            {
                if (Canvas.GetLeft(snake2[0]) == Canvas.GetLeft(snake[i])&& Canvas.GetTop(snake2[0]) == Canvas.GetTop(snake[i]))
                {
                    //关闭音乐
                    beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3", UriKind.Relative));
                    beijing.Pause();
                    Snake1Win();
                    Eacheat();//蛇二吃到蛇一
                }
            }
            #endregion
        }
        private void Eatmusic()
        {
            //添加吃到食物后音效(mp3格式)
            MediaPlayer eat = new MediaPlayer();
            eat.Open(new Uri("../../music/吃到食物.mp3", UriKind.Relative));
            eat.Play();
        }
        /// <summary>
        /// 这是用来设置蛇碰到四周时,播放的音效
        /// </summary>
        private void Music()
        {
            //添加死亡时音效(Wav格式)
            SoundPlayer eat = new SoundPlayer("../../music/fashe.wav");
            eat.Play();//播放音乐
        }
        /// <summary>
        /// 这是用来设置蛇碰到自身后游戏的关闭,以及定时器停止,游戏重新开始
        /// </summary>
        private void Eatbody()
        {
            timer1.Stop();//计时器关闭
            buju.Children.Clear();//清空容器里所有元素
            MessageBoxResult result = MessageBox.Show("果然, 妈妈说'饿坏了自己都不放过!(是否重新开始?)'", "提示(游戏结束)!", MessageBoxButton.YesNo, MessageBoxImage.Hand);
            if (result == MessageBoxResult.Yes)
            {
                //重新播放音乐
                beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3", UriKind.Relative));
                beijing.Play();
                timer1.Start();//开启计时器
                snake.Clear();//存储蛇清空
                snake2.Clear();//第二条蛇清空
                SetSnake();//重新创建蛇
                Secondsnake();//重新创建第二条蛇
                SetFood();//重新创建食物
            }
            else
            {
                this.Close();
            }
        }
        /// <summary>
        /// 这是用来设置游戏的关闭,以及定时器停止,游戏重新开始
        /// </summary>
        private void Game()
        {
            timer1.Stop();//关闭计时器
            buju.Children.Clear();//清空容器内的元素
            MessageBoxResult result=MessageBox.Show ("是否重新开始?", "提示(游戏结束)!",MessageBoxButton.YesNo,MessageBoxImage.Hand);
            beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3", UriKind.Relative));
            if (result == MessageBoxResult.Yes)//如果点击的按钮为"YES"
            {
                //重新播放音乐
                beijing.Play();
                timer1.Start();//开启计时器
                snake.Clear();//存储蛇清空
                snake2.Clear();//第二条蛇清空
                SetSnake();//重新创建第一条蛇
                Secondsnake();//重新创建第二条蛇
                SetFood();//重新创建食物
            }
            else
            {
                this.Close();
            }
        }
        //吃到自身的操作
        private void Eacheat()
        {
            timer1.Stop();//关闭计时器
            buju.Children.Clear();//清空容器内的元素
            MessageBoxResult result = MessageBox.Show("本是同根生相煎何太急(是否重新开始)?", "提示(游戏结束)!", MessageBoxButton.YesNo, MessageBoxImage.Hand);
            beijing.Open(new Uri("../../music/泠鸢yousa - 勾指起誓.mp3", UriKind.Relative));
            if (result == MessageBoxResult.Yes)//如果点击的按钮为"YES"
            {
                //重新播放音乐
                beijing.Play();
                timer1.Start();//开启计时器
                snake.Clear();//存储蛇清空
                snake2.Clear();//第二条蛇清空
                SetSnake();//重新创建第一条蛇
                Secondsnake();//重新创建第二条蛇
                SetFood();//重新创建食物
            }
            else
            {
                this.Close();
            }
        }
        //创建第一条蛇
        private void SetSnake()//第一条蛇
        {
            for (int i = 0; i < 5; i++)//开始创建蛇的长度为5
            {
                Border she = new Border();//实例化border
                she.Width = she.Height = size;//定义宽高
                if (i == 0)//蛇头颜色
                {
                    //she.
                    she.Background =new RadialGradientBrush(Colors.White,Colors.Orange) ;
                }
                else//蛇身颜色
                {
                    she.Background =new RadialGradientBrush(Colors.SkyBlue,Colors.Purple);
                }
                //设置蛇的位置
                Canvas.SetLeft(she,X/2*size-i*size);
                Canvas.SetTop(she,Y/2*size);
                she.Tag = "Right";
                she.CornerRadius = new CornerRadius(size / 2);//进行border画圆
                buju.Children.Add(she);//添加控件
                snake.Add(she);//将蛇放进这个数组列表中进行查找
            }
        }
        //添加毒食物
        private void Dufood()
        {
            du.Background = Brushes.White;
            du.Width = du.Height = size;
            du.CornerRadius = new CornerRadius(size/2);
            Canvas.SetLeft(du,p.Next(X)*size);
            Canvas.SetTop(du, p.Next(Y) * size);
            buju.Children.Add(du);
        }
        /// <summary>
        /// 这是用来创建 食物对象 是私有的
        /// </summary>
        private void SetFood()
        {
                food.Width = food.Height = size;//设置宽高
                food.CornerRadius = new CornerRadius(size / 2);//画圆操作
                //设置食物位置随机
                Canvas.SetLeft(food, p.Next(X) * size);
                Canvas.SetTop(food, p.Next(Y) * size);
                food.Background = new RadialGradientBrush(Colors.Yellow, Colors.Green);//设置渐变色
                buju.Children.Add(food);//增加食物控件到容器中
        }
        /// <summary>
        /// 这是用来创建 增加的蛇身体 是私有的
        /// </summary>
       //增加第一条蛇
        private void Addshe()
        {
            Border zshe = new Border();
            zshe.Width = zshe.Height = size;//定义宽高
            zshe.Background =new RadialGradientBrush(Colors.Silver,Colors.Red);
            //设置蛇的位置
            Canvas.SetLeft(zshe, Canvas.GetLeft(snake[snake.Count - 1]));//设置在最后一个位置
            Canvas.SetTop(zshe, Canvas.GetTop(snake[snake.Count - 1]));
            zshe.Tag = " ";
            zshe.CornerRadius = new CornerRadius(size / 2);//进行border画圆
            buju.Children.Add(zshe);//添加控件
            snake.Add(zshe);//将蛇放进这个数组列表中进行查找
        }
        private void Addtwosnake()//增加第二条蛇
        {
            Border twoshe = new Border();
            twoshe.Width = twoshe.Height = size;//定义宽高
            twoshe.Background = new RadialGradientBrush(Colors.Silver, Colors.Red);
            //设置蛇的位置
            Canvas.SetLeft(twoshe, Canvas.GetLeft(snake2[snake2.Count - 1]));//设置在最后一个位置
            Canvas.SetTop(twoshe, Canvas.GetTop(snake2[snake2.Count - 1]));
            twoshe.Tag = " ";
            twoshe.CornerRadius = new CornerRadius(size / 2);//进行border画圆
            buju.Children.Add(twoshe);//添加控件
            snake2.Add(twoshe);//将蛇放进这个数组列表中进行查找
        }
        /// <summary>
        /// 这是用来创建 第二条蛇的 是私有的
        /// </summary>
        private void Secondsnake()
        {
            for (int i = 0; i < 5; i++)
            {
                Border condsnake = new Border();//实例化border
                condsnake.Width = condsnake.Height = size;//定义宽高
                if (i == 0)//蛇头颜色
                {
                    
                    condsnake.Background = new RadialGradientBrush(Colors.Pink, Colors.Orange);
                }
                else//蛇身颜色
                {
                    condsnake.Background = new RadialGradientBrush(Colors.SkyBlue, Colors.SeaGreen);
                }
                //设置第二条蛇的位置
                Canvas.SetLeft(condsnake, X / 3 * size - i * size);
                Canvas.SetTop(condsnake, Y / 3 * size);
                condsnake.Tag = "Right";//第二条蛇的tag
                condsnake.CornerRadius = new CornerRadius(size / 2);//进行border画圆
                buju.Children.Add(condsnake);//添加控件
                snake2.Add(condsnake);//将蛇放进这个数组列表中进行查找
            }
        }
        /// <summary>
        /// 用于设置Snake1获胜后的显示
        /// </summary>
        private void Snake1Win()
        {
            MessageBox.Show("得分为:"+x,"Snake1 WIN!");
        }
        /// <summary>
        /// 用于设置Snake2获胜后的显示
        /// </summary>
        private void Snake2Win()
        {
            MessageBox.Show("得分为:" + y, "Snake2 WIN!");
        }
        private void Eatdu()
        {
            if (snake.Count==0)
            {
                Game();
            }
            if (snake2.Count==0)
            {
                Game();
            }
        }
    }
}
